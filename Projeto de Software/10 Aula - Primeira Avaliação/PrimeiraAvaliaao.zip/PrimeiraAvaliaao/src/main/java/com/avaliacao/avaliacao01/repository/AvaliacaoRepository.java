package com.avaliacao.avaliacao01.repository;

import com.avaliacao.avaliacao01.model.Avaliacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AvaliacaoRepository extends JpaRepository<Avaliacao, Integer> {
}
