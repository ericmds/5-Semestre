package com.avaliacao.avaliacao01.service;

import com.avaliacao.avaliacao01.ConexaoPorta;
import com.avaliacao.avaliacao01.model.Avaliacao;
import com.avaliacao.avaliacao01.repository.AvaliacaoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AvaliacaoService {

    private final AvaliacaoRepository avaliacaoRepository;
    private ConexaoPorta conexao;

    public AvaliacaoService(AvaliacaoRepository avaliacaoRepository) {
        this.avaliacaoRepository = avaliacaoRepository;
        this.conexao = new ConexaoPorta("COM4", 9600);
    }

    public void ligar() {
        conexao.enviaDados('1');
        Avaliacao registro = new Avaliacao("LIGADO", LocalDateTime.now());
        avaliacaoRepository.save(registro);
    }

    public void desligar() {
        conexao.enviaDados('2');
        Avaliacao registro = new Avaliacao("DESLIGADO", LocalDateTime.now());
        avaliacaoRepository.save(registro);
    }

    public List<Avaliacao> listarTodas() {
        return avaliacaoRepository.findAll();
    }
}
