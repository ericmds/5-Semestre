package com.avaliacao.avaliacao01.controller;

import com.avaliacao.avaliacao01.service.AvaliacaoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AvaliacaoController {

    private final AvaliacaoService avaliacaoService;

    public AvaliacaoController(AvaliacaoService avaliacaoService) {
        this.avaliacaoService = avaliacaoService;
    }

    @GetMapping("/ligar")
    public String ligar() {
        avaliacaoService.ligar();
        return "redirect:/";
    }

    @GetMapping("/desligar")
    public String desligar() {
        avaliacaoService.desligar();
        return "redirect:/";
    }

    @GetMapping("/listar")
    public String listar(Model model) {
        model.addAttribute("avaliacao", avaliacaoService.listarTodas());
        return "lista";
    }
}
