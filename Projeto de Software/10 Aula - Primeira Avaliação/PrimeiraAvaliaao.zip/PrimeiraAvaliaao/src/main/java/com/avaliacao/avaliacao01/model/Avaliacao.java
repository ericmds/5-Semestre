package com.avaliacao.avaliacao01.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Avaliacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 20)
    private String acao;

    @Column(nullable = false)
    private LocalDateTime dataHora;

    public Avaliacao() {}

    public Avaliacao(String acao, LocalDateTime dataHora) {
        this.acao = acao;
        this.dataHora = dataHora;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getAcao() { return acao; }
    public void setAcao(String acao) { this.acao = acao; }

    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }

    @Override
    public String toString() {
        return "Avaliacao{id=" + id + ", acao='" + acao + "', dataHora=" + dataHora + "}";
    }
}
