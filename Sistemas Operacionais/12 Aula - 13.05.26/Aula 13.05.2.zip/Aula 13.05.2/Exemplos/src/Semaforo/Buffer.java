package Semaforo;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Buffer {
    private Queue<Integer> queue = new LinkedList<>();
    private static final int CAPACITY = 5;
    private Semaphore semaforoFull = new Semaphore(0);
    private Semaphore semaforoEmpty = new Semaphore(CAPACITY);
    
    public void put(int item) throws InterruptedException {
        semaforoEmpty.acquire(); // Adquire um espaço vazio
        synchronized (this) {
            queue.add(item);
            System.out.println("Produzido: " + item);
        }
        semaforoFull.release(); // Libera um espaço cheio
    }
    
    public int get() throws InterruptedException {
        semaforoFull.acquire(); // Adquire um espaço cheio
        int item;
        synchronized (this) {
            item = queue.poll();
            System.out.println("Consumido: " + item);
        }
        semaforoEmpty.release(); // Libera um espaço vazio
        
        return item;
    }
}