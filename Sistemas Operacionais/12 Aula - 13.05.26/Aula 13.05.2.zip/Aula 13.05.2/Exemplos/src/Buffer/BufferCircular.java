package Buffer;

public class BufferCircular {
    private final int[] buffer;
    private int front = 0; // Indica a posição do próximo item a ser consumido
    private int rear = 0;  // Indica a posição do próximo item a ser produzido
    private int count = 0; // Número de itens no buffer
    
    public BufferCircular(int size) {
        buffer = new int[size];
    }
    
    public synchronized void put(int value) throws InterruptedException {
        while (count == buffer.length) {
            wait(); // Buffer cheio, espera até o consumidor consumir algum item
        }
        
        buffer[rear] = value;
        rear = (rear + 1) % buffer.length;
        count++;
        
        notifyAll(); // Notifica as threads que estão esperando para consumir
    }
    
    public synchronized int get() throws InterruptedException {
        while (count == 0) {
            wait(); // Buffer vazio, espera até o produtor produzir algum item
        }
        
        int result = buffer[front];
        front = (front + 1) % buffer.length;
        count--;
        
        notifyAll(); // Notifica as threads que estão esperando para produzir
        
        return result;
    }
}