package Buffer;

public class Principal {
    public static void main(String[] args) {
        
        BufferCircular bufferCompartilhado = new BufferCircular(5);
        
        Thread threadProdutor = new Thread(new Produtor(bufferCompartilhado));
        Thread threadConsumidor = new Thread(new Consumidor(bufferCompartilhado));
        
        threadProdutor.start();
        threadConsumidor.start();
    }
}